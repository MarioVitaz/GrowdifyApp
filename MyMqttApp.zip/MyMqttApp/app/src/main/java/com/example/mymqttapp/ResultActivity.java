package com.example.mymqttapp;

import android.app.Activity;

public class ResultActivity extends Activity {
}
